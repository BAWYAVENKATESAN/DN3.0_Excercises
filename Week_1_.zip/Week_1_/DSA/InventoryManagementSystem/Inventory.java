import java.util.*;

class Inventory {
    // Choose an appropriate data structure to store the products (e.g., ArrayList, HashMap)
    private HashMap<Integer, Product> products;

    public Inventory() {
        products = new HashMap<>();
    }

    // Method to add a product to the inventory
    public void addProduct(Product product) {
        products.put(product.productId, product);
    }

    // Method to update a product in the inventory
    public void updateProduct(int productId, Product updatedProduct) {
        if (products.containsKey(productId)) {
            products.put(productId, updatedProduct);
        }
    }

    // Method to delete a product from the inventory
    public void deleteProduct(int productId) {
        products.remove(productId);
    }

    // Method to get a product from the inventory
    public Product getProduct(int productId) {
        return products.get(productId);
    }
}