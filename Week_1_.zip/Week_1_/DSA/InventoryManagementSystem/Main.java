public class Main {
    public static void main(String[] args) {
        // Create an instance of the Inventory class
        Inventory inventory = new Inventory();

        // Create some products
        Product product1 = new Product(1, "Product 1", 10, 9.99);
        Product product2 = new Product(2, "Product 2", 20, 19.99);
        Product product3 = new Product(3, "Product 3", 30, 29.99);

        // Add products to the inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        // Update a product
        Product updatedProduct2 = new Product(2, "Updated Product 2", 25, 24.99);
        inventory.updateProduct(2, updatedProduct2);

        // Delete a product
        inventory.deleteProduct(3);

        // Get a product
        Product product = inventory.getProduct(2);
        System.out.println("Product: " + product.productName + ", Quantity: " + product.quantity + ", Price: " + product.price);
    }
}