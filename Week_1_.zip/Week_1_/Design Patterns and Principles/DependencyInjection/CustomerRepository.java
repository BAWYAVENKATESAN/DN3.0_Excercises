package exercise11;

// CustomerRepository.java
public interface CustomerRepository {
    Customer findCustomerById(String customerId);
}
