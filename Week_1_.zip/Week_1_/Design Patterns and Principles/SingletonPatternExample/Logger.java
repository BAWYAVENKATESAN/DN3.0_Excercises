public class Logger{

    //private static instance of Logger
    private static Logger instance;

    //private constructor to prevent instantiation
    private Logger() {}

    //implementing singleton patternusing synchronize
    //public static method to get instace of Logger
    public static Logger getinstance() {
        if(instance==null){
            synchronized(Logger.class){
                if(instance==null){
                    instance=new Logger();
                }
            }
        }
        return instance;
    }

    //add logging methods as needed
    public void log(String message) {
        System.out.println(message);
    }
}