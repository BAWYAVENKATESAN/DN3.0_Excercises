public interface DepartmentBasicInfo {
    String getName();
    String getLocation();
}
